# Hermes 本地插件市场

工程桥交付 ZIP 解压后，本目录名为 `hermes-engineering-bridge-local`。
按根目录 `INSTALL.txt` 安装；其中的 `companion/` 是独立的 Hermes 侧安装源。
源码仓库中的安装说明位于 `docs/HERMES_PLUGIN_INSTALL.md`，companion 源码位于
`integrations/hermes-dfsc/`。无需下载 DFSC 源码即可使用交付 ZIP。

在 DFSC Hermes 0.6 的「插件 → 市场来源 → 添加市场」中选择本目录的绝对路径，随后在「发现」安装 `hermes-engineering-bridge`。

市场使用上游原生 `.step-plugin/marketplace.json` 和 `step.plugin.json` 格式。资源包不包含账号、连接凭据、原生 session、任务账本或 Python 环境，不通过 MCP 向 Step Code 模型开放调度与审批能力。

此目录是本地市场样板。未来发布独立市场仓库时，把本目录作为仓库根目录；当前仓库内子目录不假装可直接作为 Git URL 市场入口。

验证：在 Desktop 目录运行 `node scripts/verify-hermes-marketplace.mjs`。脚本使用一次性应用数据，通过原生插件管理接口/界面验证发现、图标、安装、资源加载、卸载及重新安装，不使用真实账号或飞书。
